# Analysis Preregistration

## Research Question
Does the introduction of a flexible work policy (remote/hybrid vs. fully on-site) lead to a statistically significant increase in employee job satisfaction scores after 6 months?

## Hypotheses
* Null Hypothesis (H0): beta1 = 0 (Flexible work policy has no effect on employee job satisfaction scores).
* Alternative Hypothesis (H1): beta1 > 0 (Flexible work policy increases employee job satisfaction scores).

## Population, Sample, and Exclusions
* Target Population: Full-time corporate employees at Company X.
* Unit of Analysis: Individual employee.
* Inclusion Rules: Active full-time employees employed for at least 6 months prior to the policy start date.
* Exclusion Rules: Part-time workers, contractors, and employees with missing baseline satisfaction scores.
* Stopping Rule: Fixed sample collection at N = 500 observations recorded during the Q2 review window.

## Variables and Measures
* Outcome (Y): Job Satisfaction Score (continuous scale, 1-10, measured at 6 months).
* Predictor (X): Work Policy (1 = Flexible/Remote, 0 = On-site).
* Controls (Z): Baseline Satisfaction Score (1-10), Tenure (years).
* Transformations: Standardize continuous predictors to z-scores (M=0, SD=1).
* Missing Data: Listwise deletion for rows missing the primary outcome Y.

## Analysis Plan
* Statistical Model: Ordinary Least Squares (OLS) Multiple Linear Regression.
* Alpha Level: alpha = 0.05 (two-tailed test).
* Effect Sizes & Intervals: Report unstandardized beta1 coefficient with 95% Confidence Intervals.
* Robustness Checks: Re-run model with Huber-White heteroskedasticity-consistent standard errors (HC3).

## Deviations
* No deviations recorded to date.
